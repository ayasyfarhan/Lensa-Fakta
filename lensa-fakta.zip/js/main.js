
// Contoh kode JavaScript untuk pencarian
document.querySelector('input[type="text"]').addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
        alert('Fitur pencarian masih dalam pengembangan.');
    }
});
